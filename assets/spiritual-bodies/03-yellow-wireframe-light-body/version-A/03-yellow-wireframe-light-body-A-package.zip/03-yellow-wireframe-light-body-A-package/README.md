# 03 Yellow Wireframe Light Body — Version A

Current corrected multiview package.

Files:
- version-A/views/01-front.png
- version-A/views/02-right-side.png
- version-A/views/03-back.png
- version-A/views/04-three-quarter.png
- version-A/views/05-top-oblique-AUX.png

Notes:
- This package contains the corrected version where the energy nodes are aligned to the central body axis.
- 01–04 are main reference views.
- 05 is AUX high-angle reference.
